# --------------------------------------------------------
#           PYTHON PROGRAM
# Here is where we are going to define our set of...
# - Imports
# - Global Variables
# - Functions
# ...to achieve the functionality required.
# When executing > python 'this_file'.py in a terminal,
# the Python interpreter will load our program,
# but it will execute nothing yet.
# --------------------------------------------------------

import sys
import codecs




# ------------------------------------------
# FUNCTION filter_by_language
# ------------------------------------------
def filter_by_language(line):
  res = False
  
  stringSplit = line.split(" ")
  lang = stringSplit[0]
  if any([lang.startswith(s) for s in languages]):
    res = True
  
  return res

# ------------------------------------------
# FUNCTION map_by_kv
# ------------------------------------------
def map_by_kv(line):
  res = ""
  stringSplit = line.split(" ")
  res = (stringSplit[0], (stringSplit[1], stringSplit[2]))
  
  
  return res

# ------------------------------------------
# FUNCTION group_func
# ------------------------------------------
def group_func(x):
  lang = x[0]
  return lang

# ------------------------------------------
# FUNCTION map_values
# ------------------------------------------
def map_values(x):
  list_of_top_5 = [("",0) for i in range(num_top_entries-1)]
  for each in x:
    visits = int(each[1])
    min_val = min(list_of_top_5, key = lambda x: x[1])
    if visits > int(min_val[1]):
      min_val_indx = list_of_top_5.index(min(list_of_top_5, key = lambda x: x[1]))
      list_of_top_5[min_val_indx] = each

  return list_of_top_5
  
# ------------------------------------------
# FUNCTION my_main
# ------------------------------------------
def my_main(dataset_dir, o_file_dir, languages, num_top_entries):
    # 1. We remove the solution directory, to rewrite into it
    dbutils.fs.rm(o_file_dir, True)
  
    datasetRDD = sc.textFile(dataset_dir)
    
    filteredRDD = datasetRDD.filter(filter_by_language)
    
    mappedRDD = filteredRDD.map(map_by_kv)
    
    groupedRDD = mappedRDD.groupBy(group_func)
    
    resultRDD = groupedRDD.mapValues(map_values)

    
    resultRDD.saveAsTextFile(o_file_dir)
    #for each in resultRDD.collect():
    #  print(each)
      
  
	# Complete the Spark Job

# ---------------------------------------------------------------
#           PYTHON EXECUTION
# This is the main entry point to the execution of our program.
# It provides a call to the 'main function' defined in our
# Python program, making the Python interpreter to trigger
# its execution.
# ---------------------------------------------------------------
if __name__ == '__main__':
    dataset_dir = "/FileStore/tables/A01_my_dataset/"
    o_file_dir = "/FileStore/tables/A01_my_result/"

    languages = ["en", "es", "fr"]
    num_top_entries = 5

    my_main(dataset_dir, o_file_dir, languages, num_top_entries)
